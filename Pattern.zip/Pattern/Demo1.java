package Pattern;

public class Demo1 {

	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) // for rows
		{
			for (int j = 0; j < 5; j++) // for columns
			{
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
