package Pattern;

public class Demo6 {

	public static void main(String[] args) {
		int row = 5;
		int col = 1;
		for (int i = 0; i < row; i++) // for rows
		{
			for (int j = 0; j < col; j++) // for columns
			{
				System.out.print("*");
			}
			col++;
			System.out.println();
		}

	}

}
